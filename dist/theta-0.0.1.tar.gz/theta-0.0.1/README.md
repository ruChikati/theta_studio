# theta-studio

This is the second version of a framework I am trying to make. Please do not use this without my express permission, however feel free to use [version 1](https://github.com/ruChikati/2D-framework-v1).
